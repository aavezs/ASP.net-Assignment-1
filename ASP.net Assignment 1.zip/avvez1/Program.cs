///avvez


using System;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("///////            Made by Avvez               ///////////");

        // FOR READING AGE
        Console.WriteLine("Please enter your age:");
        int age = int.Parse(Console.ReadLine());

        // FOR READING FIRST NAME
        Console.WriteLine("Please enter your first name:");
        string firstName = Console.ReadLine();

        // FOR READING LAST NAME
        Console.WriteLine("Please enter your last name:");
        string lastName = Console.ReadLine();

        // FOR READING WEIGHT
        Console.WriteLine("Please enter your weight (in KG):");
        double weight = double.Parse(Console.ReadLine());

        // FOR READING HEIGHT
        Console.WriteLine("Please enter your height (in CM):");
        double height = double.Parse(Console.ReadLine());

        // TO GET INFO AND DISPLAY OUTPUT OF BP AND BMI
        Patient patient = new Patient(firstName, lastName, weight, height);
        Console.WriteLine(patient.GetPatientInfo());

            Console.ReadLine(); 
    }
}
