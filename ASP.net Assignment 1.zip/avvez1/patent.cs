
using System;
/// <summary>
/// avvez
/// </summary>


public class Patient
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public double WeightInKg { get; set; }
    public double HeightInCm { get; set; }

    public Patient(string firstName, string lastName, double weight, double height)
    {
        FirstName = firstName;
        LastName = lastName;
        WeightInKg = weight;
        HeightInCm = height;
    }

    public string CalculateBloodPressure(int systolic, int diastolic)
    {
        if (systolic < 0 || diastolic < 0)
        {
            return "Invalid value";
        }

        if (systolic < 120 && diastolic < 80)
        {
            return "NORMAL";
        }
        else if (systolic < 130 && diastolic < 80)
        {
            return "ELEVATED";
        }
        else if (systolic < 140 || diastolic < 90)
        {
            return "HIGH BLOOD PRESSURE ";
        }
        else if (systolic < 180 || diastolic < 120)
        {
            return "HIGH BLOOD PRESSURE ";
        }
        else if (systolic >= 180 || diastolic >= 120)
        {
            return "HYPERTENSIVE CRISIS";
        }
       
    }

    public double CalculateBMI()
    {
        double heightInMeter = HeightInCm / 100;
        return WeightInKg / (heightInMeter * heightInMeter);
    }

    public string GetPatientInfo()
    {
        string fName = $"{FirstName} {LastName}";
        string bPres = CalculateBloodPressure(120, 80);
        double bmi = CalculateBMI();
        string bmiStat = "";

        if (bmi >= 25.0)
        {
            bmiStat = "Overweight";
        }
        else if (bmi >= 18.5 && bmi <= 24.9)
        {
            bmiStat = "Normal (In the healthy range)";
        }
        else
        {
            bmiStat = "Underweight";
        }

        return $"Full Name: {fName}\nWeight: {WeightInKg} KG\nHeight: {HeightInCm} CM\nBlood Pressure: {bPres}\nBMI: {bmi}\nBMI Status: {bmiStat}";
    }
}
